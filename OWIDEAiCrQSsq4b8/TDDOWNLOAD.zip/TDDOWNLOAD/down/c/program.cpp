void init(int n,int m){
    srand(23333);
}

int doit(int opttype,int input1,int input2){
    return rand();
}