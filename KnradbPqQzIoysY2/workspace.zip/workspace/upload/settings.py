# settings
u_token = "820ebf22968312c585de589ef3a8bfd28eea0dde"
base_url = "https://api.github.com/"
user_name = "tooyoungtoosimple1989"
user_mail = "57655717+tooyoungtoosimple1989@users.noreply.github.com"
account_name = "urlib"
repo_name = "support"
simple_repo_name = "young"
proxy_repo_name = "sorry"
image_repo_name = "tim"
gen_method = "sha1"

proxies = {"http": "http://127.0.0.1:1080",
           "https": "http://127.0.0.1:1080"}
