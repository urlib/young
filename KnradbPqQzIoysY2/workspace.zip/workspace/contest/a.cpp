#include "bits/stdc++.h"
typedef long long ll;

template <typename T>
inline void read(T &x)
{
    x = 0;
    bool neg = 0;
    char c = getchar();
    for (; !isdigit(c); c = getchar())
    {
        if (c == '-')
        {
            neg = 1;
        }
    }
    for (; isdigit(c); c = getchar())
    {
        x = x * 10 + c - '0';
    }
    if (neg)
    {
        x = -x;
    }
}

const int N = 1000000 + 5;
int n;
int head[N], to[N], nxt[N], cnt;

inline void add_edge(int u, int v)
{
    to[++cnt] = v;
    nxt[u] = head[u];
    head[u] = cnt;
}

int n;
int main()
{
    read(n);
    for (int i = 1; i <= n; i++)
    {
        int x;
        read(x);
        add_edge(i, x);
    }
    for (int i = 1; i <= n;i++)
    {
        
    }
}