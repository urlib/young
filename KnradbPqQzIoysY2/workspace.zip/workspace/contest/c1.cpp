#include "bits/stdc++.h"

const int N = 1000000 + 5;
int kmp[N];
char a[N], b[N];
inline int gc(char *s)
{
    int pos = 0;
    char c = getchar();
    for (; !isalpha(c); c = getchar())
        ;
    for (; isalpha(c); c = getchar())
    {
        s[++pos] = c;
    }
    return pos;
}

int main()
{
    int len_a = gc(a), len_b = gc(b);
    int j = 0;
    for (int i = 2; i <= len_b; i++)
    {
        for (; j > 0 && b[i] != b[j + 1];
             j = kmp[j])
            ;
        if (b[j + 1] == b[i])
        {
            j++;
        }
        kmp[i] = j;
    }
    j = 0;
    for (int i = 1; i <= len_a; i++)
    {
        for (; j > 0 && b[j + 1] != a[i]; j = kmp[j])
            ;
        if (b[j + 1] == a[i])
        {
            j++;
        }
        if (j == len_b)
        {
            printf("%d\n", i - len_b + 1);
            j = kmp[j];
        }
    }

    for (int i = 1; i <= len_b; i++)
    {
        printf("%d ", kmp[i]);
    }
    puts("");
}