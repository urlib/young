#include "bits/stdc++.h"

const int N = 1000000 + 5;
int kmp[N];
char a[N], b[N];

int main()
{
    scanf("%s", a + 1);
    scanf("%s", b + 1);
    int len_a = strlen(a + 1), len_b = strlen(b + 1);
    int j = 0;
    for (int i = 2; i <= len_b; i++)
    {
        for (; j > 0 && b[i] != b[j + 1]; j = kmp[j])
            ;
        if (b[j + 1] == b[i])
        {
            j++;
        }
        kmp[i] = j;
    }
    j = 0;
    for (int i = 1; i <= len_a; i++)
    {
        for (; j > 0 && b[j + 1] != a[i]; j = kmp[j])
            ;
        if (b[j + 1] == a[i])
        {
            j++;
        }
        if (j == len_b)
        {
            printf("%d\n", i - len_b + 1);
        }
    }

    for (int i = 1; i <= len_b; i++)
    {
        printf("%d ", kmp[i]);
    }
    putchar('\n');
}