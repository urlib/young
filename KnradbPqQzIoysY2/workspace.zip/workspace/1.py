import requests
import time
import random

while (1):
    url = "https://dev.xjoi.net/contest/1328/problem/2/submit"
    headers = {
        "content-length": "392",
        "content-type": "application/x-www-form-urlencoded",
        "cookie": "XJOISESSION=%7B%22inner_user%22%3A%220%22%2C%22exp%22%3A1573802427%2C%22uid%22%3A%229681%22%2C%22user%22%3A%22whql%22%2C%22level%22%3A%222%22%2C%22ac%22%3A0%2C%22time_submit%22%3A0%2C%22vlevel%22%3A%220%22%2C%22logid%22%3A853%7D.58d5f400d7686f2b21baa79f4fae9b90692a791f9fb97e150dbb5caeaaf21c56",
        "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36"}
    data = "language=g%2B%2B&source=%23include+%3Cbits%2Fstdc%2B%2B.h%3E%0D%0Ausing+namespace+std%3B%0D%0A+++%0D%0Aint+main%28%29%0D%0A%7B%0D%0A++++freopen%28%22b.in%22%2C+%22r%22%2C+stdin%29%3B%0D%0A++++freopen%28%22b.out%22%2C+%22w%22%2C+stdout%29%3B%0D%0A++++srand%28time%280%29+%5E+clock%28%29%29%3B%0D%0A++++puts%28rand%28%29+%25+2+%3F+%22Yes%22+%3A+%22No%22%29%3B%0D%0A+++%0D%0A++++return+0%3B%0D%0A%7D"
    result = requests.post(url=url, headers=headers,
                           data=data)
    print(result.status_code)
    sleep_time = random.randint(10, 20)
    time.sleep(sleep_time)
