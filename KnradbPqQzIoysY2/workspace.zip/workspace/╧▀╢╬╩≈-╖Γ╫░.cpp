#pragma GCC optimize("2,Ofast,inline")
#include <bits/stdc++.h>
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define LL long long
#define pii pair<int, int>
using namespace std;
const int N = 3e5 + 10;

template <typename T>
T read(T &x)
{
    int f = 0;
    register char c = getchar();
    while (c > '9' || c < '0')
        f |= (c == '-'), c = getchar();
    for (x = 0; c >= '0' && c <= '9'; c = getchar())
        x = (x << 3) + (x << 1) + (c ^ 48);
    if (f)
        x = -x;
    return x;
}

int n, m;
int a[N];

struct vqq
{
    int l, r, g, id;

    bool operator<(const vqq &b) const
    {
        return g > b.g;
    }
} girl[N];

struct SegTree
{
    int tr[N << 2], mi[N << 2], mx[N << 2];
    int tag[N << 2];

    void pushup(int x)
    {
        mi[x] = min(mi[x << 1], mi[x << 1 | 1]);
        mx[x] = max(mx[x << 1], mx[x << 1 | 1]);
    }

    void pushdown(int x)
    {
        tr[x << 1] += tag[x];
        tr[x << 1 | 1] += tag[x];
        mi[x << 1] += tag[x];
        mi[x << 1 | 1] += tag[x];
        mx[x << 1] += tag[x];
        mx[x << 1 | 1] += tag[x];
        tag[x << 1] += tag[x];
        tag[x << 1 | 1] += tag[x];
        tag[x] = 0;
    }

    void build(int x, int l, int r)
    {
        if (l == r)
        {
            tr[x] = mi[x] = mx[x] = a[l];
            return;
        }
        int mid = (l + r) >> 1;
        build(x << 1, l, mid);
        build(x << 1 | 1, mid + 1, r);
        pushup(x);
    }

    void update(int x, int l, int r, int ql, int qr)
    {
        if (ql <= l && r <= qr)
        {
            --tag[x];
            --mi[x];
            --mx[x];
            --tr[x];
            return;
        }
        pushdown(x);
        int mid = (l + r) >> 1;
        if (mid >= ql)
        {
            update(x << 1, l, mid, ql, qr);
        }
        if (mid < qr)
        {
            update(x << 1 | 1, mid + 1, r, ql, qr);
        }
        pushup(x);
    }

    int query_mn(int x, int l, int r, int ql, int qr)
    {
        if (ql > qr)
            return -1;
        if (ql <= l && r <= qr)
        {
            return mi[x];
        }
        pushdown(x);
        int mid = (l + r) >> 1, ans = 1e9;
        if (mid >= ql)
        {
            ans = min(ans, query_mn(x << 1, l, mid, ql, qr));
        }
        if (mid < qr)
        {
            ans = min(ans, query_mn(x << 1 | 1, mid + 1, r, ql, qr));
        }
        return ans;
    }

    int query_mx(int x, int l, int r, int ql, int qr)
    {
        if (ql > qr)
            return 0;
        if (ql <= l && r <= qr)
        {
            return mx[x];
        }
        pushdown(x);
        int mid = (l + r) >> 1, ans = -1e9;
        if (mid >= ql)
        {
            ans = max(ans, query_mx(x << 1, l, mid, ql, qr));
        }
        if (mid < qr)
        {
            ans = max(ans, query_mx(x << 1 | 1, mid + 1, r, ql, qr));
        }
        return ans;
    }
} t1, t2;

int main()
{
    read(n);
    read(m);
    for (int i = 1; i <= n; ++i)
    {
        read(a[i]);
        a[i] += a[i - 1];
    }
    for (int i = 1; i <= m; ++i)
    {
        read(girl[i].l);
        read(girl[i].r);
        read(girl[i].g);
        girl[i].id = i;
    }
    t1.build(1, 0, n);
    t2.build(1, 0, n);
    sort(girl + 1, girl + m + 1);
    LL ans = 0;
    for (int i = 1; i <= m; ++i)
    {
        int s1 = t1.query_mx(1, 0, n, 0, girl[i].l - 1);
        int s2 = t2.query_mn(1, 0, n, girl[i].r, n);
        if (s2 > s1)
        {
            ans += girl[i].g;
            t1.update(1, 0, n, girl[i].l, n);
            t2.update(1, 0, n, girl[i].r, n);
        }
    }
    cout << ans << endl;
    return 0;
}